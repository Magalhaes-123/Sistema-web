# ERPNova Frontend

React 18 + Vite + Recharts

## Instalação

```bash
npm install
```

## Desenvolvimento

```bash
npm run dev
```

Acesso em `http://localhost:3000`

## Build para Produção

```bash
npm run build
```

## Estrutura

```
src/
├── App.jsx              # Componente principal com navegação
├── main.jsx
├── pages/               # Páginas por módulo
│   ├── Dashboard.jsx
│   ├── Inventory.jsx
│   ├── Sales.jsx
│   ├── Purchases.jsx
│   ├── Invoicing.jsx
│   ├── Treasury.jsx
│   ├── Finance.jsx
│   ├── Logistics.jsx
│   ├── Marketing.jsx
│   ├── Reports.jsx
│   └── Settings.jsx
├── services/
│   └── api.js           # Chamadas ao backend
├── hooks/
│   └── useApi.js        # Hook para dados da API
└── utils/
    └── helpers.js       # Funções auxiliares
```

## Módulos

### Dashboard
- KPIs em tempo real
- Gráficos de receitas
- Alertas do sistema
- Últimas encomendas

### Inventário
- Gestão de produtos
- Armazéns e stock
- Movimentos de stock

### Vendas
- Clientes
- Encomendas
- Cotações
- Devoluções

### Compras
- Fornecedores
- Encomendas de compra
- Devoluções

### Faturação
- Faturas
- Recibos
- Notas de crédito/débito

### Tesouraria
- Caixas
- Contas bancárias
- Pagamentos
- Reconciliação

### Finanças
- Contabilidade
- Diários
- Orçamentos
- Centros de custo

### Logística
- Entregas
- Motoristas
- Veículos
- Rotas

### Marketing
- Campanhas
- Leads
- CRM

### Relatórios
- Vendas
- Financeiros
- Inventário
- Tesouraria

### Configurações
- Dados da empresa
- Utilizadores
- Permissões
- Backup

## Variáveis de Ambiente

```
VITE_API_URL=http://localhost:8000/api
```

## Tecnologias

- React 18
- Vite
- Recharts para gráficos
- Axios para HTTP (integração futura)
