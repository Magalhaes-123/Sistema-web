import { useState, useEffect } from "react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";

// ── Data ──────────────────────────────────────────────────────────────────────
const revenueData = [
  { month: "Jan", receitas: 142000, despesas: 98000, lucro: 44000 },
  { month: "Fev", receitas: 168000, despesas: 112000, lucro: 56000 },
  { month: "Mar", receitas: 195000, despesas: 125000, lucro: 70000 },
  { month: "Abr", receitas: 178000, despesas: 118000, lucro: 60000 },
  { month: "Mai", receitas: 221000, despesas: 134000, lucro: 87000 },
  { month: "Jun", receitas: 257000, despesas: 149000, lucro: 108000 },
];

const stockData = [
  { name: "Produtos", value: 1248, color: "#6366f1" },
  { name: "Categorias", value: 48, color: "#22d3ee" },
  { name: "Marcas", value: 32, color: "#f59e0b" },
  { name: "Armazéns", value: 8, color: "#10b981" },
];

const salesByModule = [
  { name: "Seg", vendas: 34, compras: 22, devoluções: 3 },
  { name: "Ter", vendas: 45, compras: 28, devoluções: 5 },
  { name: "Qua", vendas: 38, compras: 19, devoluções: 2 },
  { name: "Qui", vendas: 52, compras: 31, devoluções: 4 },
  { name: "Sex", vendas: 61, compras: 37, devoluções: 6 },
  { name: "Sáb", vendas: 29, compras: 15, devoluções: 1 },
  { name: "Dom", vendas: 18, compras: 8, devoluções: 0 },
];

const recentOrders = [
  { id: "PV-2024-0891", cliente: "Tech Solutions Lda", valor: "€12.450", status: "Entregue", data: "Hoje, 14:32" },
  { id: "PV-2024-0890", cliente: "Global Imports SA", valor: "€8.200", status: "Em Trânsito", data: "Hoje, 11:15" },
  { id: "PV-2024-0889", cliente: "MegaStore Porto", valor: "€34.700", status: "Pendente", data: "Ontem, 17:48" },
  { id: "PV-2024-0888", cliente: "Distribuidora Norte", valor: "€6.100", status: "Processando", data: "Ontem, 09:20" },
  { id: "PV-2024-0887", cliente: "Retail Express", valor: "€19.850", status: "Entregue", data: "26 Mai, 16:00" },
];

const alerts = [
  { type: "danger", icon: "⚠", msg: "5 produtos abaixo do stock mínimo", time: "Agora" },
  { type: "warning", icon: "🕐", msg: "3 faturas a vencer nos próximos 2 dias", time: "1h atrás" },
  { type: "info", icon: "📦", msg: "Encomenda #PC-0341 recebida no armazém", time: "2h atrás" },
  { type: "success", icon: "✅", msg: "Reconciliação bancária concluída", time: "3h atrás" },
];

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt = (n) =>
  n >= 1000000 ? `€${(n / 1000000).toFixed(1)}M` : `€${(n / 1000).toFixed(0)}k`;

const statusColor = {
  Entregue: { bg: "#d1fae5", text: "#065f46" },
  "Em Trânsito": { bg: "#dbeafe", text: "#1e40af" },
  Pendente: { bg: "#fef3c7", text: "#92400e" },
  Processando: { bg: "#ede9fe", text: "#5b21b6" },
};

// ── Sub-components ─────────────────────────────────────────────────────────────
function KpiCard({ label, value, delta, icon, accent }) {
  const positive = delta >= 0;
  return (
    <div style={{
      background: "#fff",
      borderRadius: 16,
      padding: "20px 24px",
      boxShadow: "0 1px 3px rgba(0,0,0,.06), 0 4px 16px rgba(0,0,0,.04)",
      borderLeft: `4px solid ${accent}`,
      display: "flex",
      flexDirection: "column",
      gap: 8,
      flex: 1,
      minWidth: 180,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: "#64748b", letterSpacing: ".5px", textTransform: "uppercase" }}>{label}</span>
        <span style={{ fontSize: 22 }}>{icon}</span>
      </div>
      <div style={{ fontSize: 28, fontWeight: 800, color: "#0f172a", fontFamily: "'DM Mono', monospace" }}>{value}</div>
      <div style={{ fontSize: 12, color: positive ? "#10b981" : "#ef4444", fontWeight: 600 }}>
        {positive ? "▲" : "▼"} {Math.abs(delta)}% vs mês anterior
      </div>
    </div>
  );
}

function SectionCard({ title, children, style = {} }) {
  return (
    <div style={{
      background: "#fff",
      borderRadius: 16,
      padding: "20px 24px",
      boxShadow: "0 1px 3px rgba(0,0,0,.06), 0 4px 16px rgba(0,0,0,.04)",
      ...style,
    }}>
      <div style={{ fontSize: 14, fontWeight: 700, color: "#0f172a", marginBottom: 16, letterSpacing: ".3px" }}>{title}</div>
      {children}
    </div>
  );
}

const NAV_ITEMS = [
  { icon: "⊞", label: "Dashboard", active: true },
  { icon: "📦", label: "Inventário" },
  { icon: "🛒", label: "Compras" },
  { icon: "💼", label: "Vendas" },
  { icon: "🧾", label: "Faturação" },
  { icon: "🏦", label: "Tesouraria" },
  { icon: "📊", label: "Finanças" },
  { icon: "🚚", label: "Logística" },
  { icon: "📣", label: "Marketing" },
  { icon: "📈", label: "Relatórios" },
];

// ── Main ──────────────────────────────────────────────────────────────────────
export default function ERPDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeNav, setActiveNav] = useState("Dashboard");
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(t);
  }, []);

  const timeStr = now.toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
  const dateStr = now.toLocaleDateString("pt-PT", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

  return (
    <div style={{
      display: "flex",
      height: "100vh",
      fontFamily: "'Inter', 'Segoe UI', sans-serif",
      background: "#f1f5f9",
      overflow: "hidden",
    }}>
      {/* ── Sidebar ── */}
      <aside style={{
        width: sidebarOpen ? 220 : 64,
        background: "linear-gradient(180deg, #0f172a 0%, #1e293b 100%)",
        display: "flex",
        flexDirection: "column",
        transition: "width .25s ease",
        overflow: "hidden",
        flexShrink: 0,
      }}>
        {/* Logo */}
        <div style={{
          padding: "20px 16px",
          borderBottom: "1px solid rgba(255,255,255,.08)",
          display: "flex",
          alignItems: "center",
          gap: 10,
          cursor: "pointer",
        }} onClick={() => setSidebarOpen(!sidebarOpen)}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: "linear-gradient(135deg, #6366f1, #22d3ee)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 16, flexShrink: 0,
          }}>⚡</div>
          {sidebarOpen && (
            <span style={{ color: "#fff", fontWeight: 800, fontSize: 16, whiteSpace: "nowrap", letterSpacing: "-0.5px" }}>
              ERP<span style={{ color: "#6366f1" }}>Nova</span>
            </span>
          )}
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: "12px 8px", display: "flex", flexDirection: "column", gap: 2 }}>
          {NAV_ITEMS.map(({ icon, label }) => {
            const isActive = activeNav === label;
            return (
              <button key={label} onClick={() => setActiveNav(label)} style={{
                display: "flex", alignItems: "center", gap: 12,
                padding: "10px 12px", borderRadius: 10, border: "none", cursor: "pointer",
                background: isActive ? "rgba(99,102,241,.25)" : "transparent",
                color: isActive ? "#a5b4fc" : "rgba(255,255,255,.5)",
                fontSize: 13, fontWeight: isActive ? 700 : 400,
                transition: "all .15s", textAlign: "left", whiteSpace: "nowrap",
              }}>
                <span style={{ fontSize: 16, flexShrink: 0 }}>{icon}</span>
                {sidebarOpen && label}
                {isActive && sidebarOpen && (
                  <div style={{
                    marginLeft: "auto", width: 6, height: 6,
                    borderRadius: "50%", background: "#6366f1",
                  }} />
                )}
              </button>
            );
          })}
        </nav>

        {/* User */}
        <div style={{
          padding: "12px 16px", borderTop: "1px solid rgba(255,255,255,.08)",
          display: "flex", alignItems: "center", gap: 10,
        }}>
          <div style={{
            width: 32, height: 32, borderRadius: "50%",
            background: "linear-gradient(135deg, #f59e0b, #ef4444)",
            display: "flex", alignItems: "center", justifyContent: "center",
            color: "#fff", fontWeight: 700, fontSize: 13, flexShrink: 0,
          }}>AM</div>
          {sidebarOpen && (
            <div>
              <div style={{ color: "#fff", fontSize: 12, fontWeight: 600 }}>Admin Master</div>
              <div style={{ color: "rgba(255,255,255,.4)", fontSize: 11 }}>Administrador</div>
            </div>
          )}
        </div>
      </aside>

      {/* ── Main ── */}
      <main style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Topbar */}
        <header style={{
          background: "#fff",
          borderBottom: "1px solid #e2e8f0",
          padding: "0 28px",
          height: 60,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexShrink: 0,
        }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 800, color: "#0f172a" }}>Dashboard</div>
            <div style={{ fontSize: 12, color: "#94a3b8", textTransform: "capitalize" }}>{dateStr}</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{
              background: "#f8fafc", border: "1px solid #e2e8f0",
              borderRadius: 8, padding: "6px 14px", fontSize: 13, color: "#64748b",
              display: "flex", alignItems: "center", gap: 6,
            }}>
              🔍 <span>Pesquisar...</span>
            </div>
            <div style={{
              position: "relative", width: 36, height: 36,
              background: "#f8fafc", border: "1px solid #e2e8f0",
              borderRadius: 8, display: "flex", alignItems: "center",
              justifyContent: "center", cursor: "pointer", fontSize: 16,
            }}>
              🔔
              <div style={{
                position: "absolute", top: 6, right: 6,
                width: 8, height: 8, borderRadius: "50%",
                background: "#ef4444", border: "2px solid #fff",
              }} />
            </div>
            <div style={{
              fontFamily: "'DM Mono', monospace",
              fontSize: 13, color: "#0f172a", fontWeight: 600,
            }}>{timeStr}</div>
          </div>
        </header>

        {/* Content */}
        <div style={{ flex: 1, overflow: "auto", padding: "24px 28px" }}>

          {/* KPIs */}
          <div style={{ display: "flex", gap: 16, marginBottom: 24, flexWrap: "wrap" }}>
            <KpiCard label="Receitas (Mês)" value="€257k" delta={14.2} icon="💰" accent="#10b981" />
            <KpiCard label="Vendas" value="1.842" delta={8.7} icon="📋" accent="#6366f1" />
            <KpiCard label="Clientes Ativos" value="346" delta={5.1} icon="👥" accent="#22d3ee" />
            <KpiCard label="Stock Total" value="48.291" delta={-2.3} icon="📦" accent="#f59e0b" />
            <KpiCard label="A Receber" value="€89k" delta={-6.4} icon="🧾" accent="#ef4444" />
          </div>

          {/* Row 2: Revenue chart + Alerts */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 16, marginBottom: 16 }}>
            <SectionCard title="📈 Receitas vs Despesas vs Lucro (6 meses)">
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={revenueData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="gR" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gD" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gL" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="month" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickFormatter={fmt} axisLine={false} tickLine={false} />
                  <Tooltip formatter={(v) => fmt(v)} contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }} />
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                  <Area type="monotone" dataKey="receitas" name="Receitas" stroke="#6366f1" strokeWidth={2} fill="url(#gR)" />
                  <Area type="monotone" dataKey="despesas" name="Despesas" stroke="#ef4444" strokeWidth={2} fill="url(#gD)" />
                  <Area type="monotone" dataKey="lucro" name="Lucro" stroke="#10b981" strokeWidth={2} fill="url(#gL)" />
                </AreaChart>
              </ResponsiveContainer>
            </SectionCard>

            <SectionCard title="🔔 Alertas do Sistema">
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {alerts.map((a, i) => {
                  const colors = {
                    danger: { bg: "#fef2f2", border: "#fecaca", text: "#991b1b" },
                    warning: { bg: "#fffbeb", border: "#fde68a", text: "#92400e" },
                    info: { bg: "#eff6ff", border: "#bfdbfe", text: "#1e40af" },
                    success: { bg: "#f0fdf4", border: "#bbf7d0", text: "#065f46" },
                  }[a.type];
                  return (
                    <div key={i} style={{
                      background: colors.bg,
                      border: `1px solid ${colors.border}`,
                      borderRadius: 10, padding: "10px 12px",
                      display: "flex", gap: 8, alignItems: "flex-start",
                    }}>
                      <span style={{ fontSize: 14 }}>{a.icon}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 12, color: colors.text, fontWeight: 600 }}>{a.msg}</div>
                        <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 2 }}>{a.time}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </SectionCard>
          </div>

          {/* Row 3: Weekly sales bar + Inventory pie + Orders table */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 260px", gap: 16, marginBottom: 16 }}>
            <SectionCard title="📊 Movimentos Semanais">
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={salesByModule} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }} />
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="vendas" name="Vendas" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="compras" name="Compras" fill="#22d3ee" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="devoluções" name="Devoluções" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </SectionCard>

            <SectionCard title="📦 Inventário" style={{ display: "flex", flexDirection: "column" }}>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={stockData} cx="50%" cy="50%" innerRadius={45} outerRadius={70}
                    dataKey="value" paddingAngle={3}>
                    {stockData.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                  <Tooltip formatter={(v, n) => [v, n]} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 4 }}>
                {stockData.map((d) => (
                  <div key={d.name} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 12 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <div style={{ width: 8, height: 8, borderRadius: "50%", background: d.color }} />
                      <span style={{ color: "#64748b" }}>{d.name}</span>
                    </div>
                    <span style={{ fontWeight: 700, color: "#0f172a", fontFamily: "'DM Mono', monospace" }}>{d.value}</span>
                  </div>
                ))}
              </div>
            </SectionCard>
          </div>

          {/* Row 4: Orders table */}
          <SectionCard title="🛒 Últimas Encomendas de Venda">
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: "2px solid #f1f5f9" }}>
                  {["Nº Encomenda", "Cliente", "Valor", "Estado", "Data"].map((h) => (
                    <th key={h} style={{
                      textAlign: "left", padding: "8px 12px",
                      color: "#64748b", fontWeight: 600, fontSize: 12,
                      textTransform: "uppercase", letterSpacing: ".5px",
                    }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((o, i) => (
                  <tr key={o.id} style={{
                    borderBottom: "1px solid #f8fafc",
                    background: i % 2 === 0 ? "transparent" : "#fafafa",
                  }}>
                    <td style={{ padding: "10px 12px", fontFamily: "'DM Mono', monospace", color: "#6366f1", fontWeight: 600 }}>{o.id}</td>
                    <td style={{ padding: "10px 12px", color: "#0f172a", fontWeight: 500 }}>{o.cliente}</td>
                    <td style={{ padding: "10px 12px", fontFamily: "'DM Mono', monospace", fontWeight: 700, color: "#0f172a" }}>{o.valor}</td>
                    <td style={{ padding: "10px 12px" }}>
                      <span style={{
                        background: statusColor[o.status]?.bg || "#f1f5f9",
                        color: statusColor[o.status]?.text || "#334155",
                        borderRadius: 6, padding: "3px 10px",
                        fontSize: 11, fontWeight: 700,
                      }}>{o.status}</span>
                    </td>
                    <td style={{ padding: "10px 12px", color: "#94a3b8", fontSize: 12 }}>{o.data}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </SectionCard>

        </div>
      </main>
    </div>
  );
}
