import { useState } from "react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";

const revenueData = [
  { month: "Jan", receitas: 142000, despesas: 98000, lucro: 44000 },
  { month: "Fev", receitas: 168000, despesas: 112000, lucro: 56000 },
  { month: "Mar", receitas: 195000, despesas: 125000, lucro: 70000 },
  { month: "Abr", receitas: 178000, despesas: 118000, lucro: 60000 },
  { month: "Mai", receitas: 221000, despesas: 134000, lucro: 87000 },
  { month: "Jun", receitas: 257000, despesas: 149000, lucro: 108000 },
];

const stockData = [
  { name: "Produtos", value: 1248, color: "#0099ff" },
  { name: "Categorias", value: 48, color: "#00d4ff" },
  { name: "Marcas", value: 32, color: "#ff8787" },
  { name: "Armazéns", value: 8, color: "#37c74d" },
];

const recentOrders = [
  { id: "PV-2024-0891", cliente: "Tech Solutions", valor: "€12.450", status: "Entregue", data: "Hoje" },
  { id: "PV-2024-0890", cliente: "Global Imports", valor: "€8.200", status: "Em Trânsito", data: "Hoje" },
  { id: "PV-2024-0889", cliente: "MegaStore", valor: "€34.700", status: "Pendente", data: "Ontem" },
  { id: "PV-2024-0888", cliente: "Distribuidora", valor: "€6.100", status: "Processando", data: "Ontem" },
];

const KpiCard = ({ label, value, delta, icon, color }) => (
  <div style={{
    background: "#fff",
    borderRadius: 12,
    padding: "20px",
    boxShadow: "0 1px 3px rgba(0,0,0,.06)",
    borderLeft: `4px solid ${color}`,
    flex: 1,
    minWidth: 160,
  }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
      <span style={{ fontSize: 11, fontWeight: 700, color: "#6c757d", textTransform: "uppercase" }}>{label}</span>
      <span style={{ fontSize: 20 }}>{icon}</span>
    </div>
    <div style={{ fontSize: 24, fontWeight: 900, color: "#0a1428" }}>{value}</div>
    <div style={{ fontSize: 11, color: delta >= 0 ? "#37c74d" : "#dc3545", fontWeight: 700, marginTop: 8 }}>
      {delta >= 0 ? "▲" : "▼"} {Math.abs(delta)}% vs mês anterior
    </div>
  </div>
);

export default function Dashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState("6m");

  return (
    <div style={{ padding: "24px 28px" }}>
      <style>{`
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .kpi-card { animation: fadeIn 0.5s ease-out; }
        .chart-card { animation: fadeIn 0.6s ease-out; }
        .stat-card { animation: fadeIn 0.7s ease-out; }
      `}</style>

      {/* KPIs */}
      <div style={{ display: "flex", gap: 16, marginBottom: 24, flexWrap: "wrap" }}>
        <KpiCard label="Receitas (Mês)" value="€257k" delta={14.2} icon="💰" color="#0099ff" />
        <KpiCard label="Vendas" value="1.842" delta={8.7} icon="📋" color="#00d4ff" />
        <KpiCard label="Clientes" value="346" delta={5.1} icon="👥" color="#37c74d" />
        <KpiCard label="Stock" value="48k" delta={-2.3} icon="📦" color="#ff8787" />
        <KpiCard label="A Receber" value="€89k" delta={-6.4} icon="🧾" color="#ffc107" />
      </div>

      {/* Charts Row */}
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16, marginBottom: 24 }}>
        <div className="chart-card" style={{
          background: "#fff",
          borderRadius: 12,
          padding: "20px",
          boxShadow: "0 1px 3px rgba(0,0,0,.06)",
        }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#0a1428", marginBottom: 16 }}>
            📈 Receitas vs Despesas vs Lucro
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="gR" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0099ff" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#0099ff" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gD" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ff8787" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#ff8787" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gL" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#37c74d" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#37c74d" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e9f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: "#6c757d" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#6c757d" }} tickFormatter={(v) => `€${(v / 1000).toFixed(0)}k`} axisLine={false} tickLine={false} />
              <Tooltip formatter={(v) => `€${(v / 1000).toFixed(0)}k`} contentStyle={{ borderRadius: 8, border: "1px solid #e5e9f0" }} />
              <Legend />
              <Area type="monotone" dataKey="receitas" name="Receitas" stroke="#0099ff" fill="url(#gR)" />
              <Area type="monotone" dataKey="despesas" name="Despesas" stroke="#ff8787" fill="url(#gD)" />
              <Area type="monotone" dataKey="lucro" name="Lucro" stroke="#37c74d" fill="url(#gL)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card" style={{
          background: "#fff",
          borderRadius: 12,
          padding: "20px",
          boxShadow: "0 1px 3px rgba(0,0,0,.06)",
          display: "flex",
          flexDirection: "column",
        }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "#0a1428", marginBottom: 16 }}>📦 Inventário</div>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={stockData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" paddingAngle={2}>
                {stockData.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 6 }}>
            {stockData.map((d) => (
              <div key={d.name} style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}>
                <span style={{ color: "#495057" }}>
                  <span style={{ display: "inline-block", width: 8, height: 8, borderRadius: "50%", background: d.color, marginRight: 6 }}></span>
                  {d.name}
                </span>
                <span style={{ fontWeight: 700, color: "#0a1428" }}>{d.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="stat-card" style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: "#0a1428", marginBottom: 16 }}>🛒 Últimas Encomendas</div>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: "2px solid #e5e9f0" }}>
              {["Nº", "Cliente", "Valor", "Estado", "Data"].map((h) => (
                <th key={h} style={{
                  textAlign: "left",
                  padding: "12px",
                  color: "#6c757d",
                  fontWeight: 700,
                  fontSize: 11,
                  textTransform: "uppercase",
                }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {recentOrders.map((o, i) => (
              <tr key={o.id} style={{
                borderBottom: "1px solid #f8f9fa",
                background: i % 2 === 0 ? "transparent" : "#f8f9fa",
              }}>
                <td style={{ padding: "12px", fontWeight: 700, color: "#0099ff", fontSize: 12 }}>{o.id}</td>
                <td style={{ padding: "12px", color: "#0a1428", fontWeight: 500 }}>{o.cliente}</td>
                <td style={{ padding: "12px", fontWeight: 700, color: "#0a1428" }}>{o.valor}</td>
                <td style={{ padding: "12px" }}>
                  <span style={{
                    padding: "4px 12px",
                    borderRadius: 6,
                    fontSize: 11,
                    fontWeight: 700,
                    background: o.status === "Entregue" ? "#d4edda" : o.status === "Em Trânsito" ? "#cfe2ff" : o.status === "Pendente" ? "#fff3cd" : "#f8d7da",
                    color: o.status === "Entregue" ? "#155724" : o.status === "Em Trânsito" ? "#084298" : o.status === "Pendente" ? "#856404" : "#721c24",
                  }}>
                    {o.status}
                  </span>
                </td>
                <td style={{ padding: "12px", color: "#6c757d", fontSize: 12 }}>{o.data}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
