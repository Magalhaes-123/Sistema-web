export function Finance({ submodule }) {
  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ margin: "0 0 20px 0", fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Finanças</h2>
      <div style={{ background: "#fff", borderRadius: 12, padding: "20px", boxShadow: "0 1px 3px rgba(0,0,0,.06)" }}>
        <div style={{ color: "#495057", fontSize: 14 }}>Submódulo: <strong>{submodule}</strong></div>
      </div>
    </div>
  );
}

export default Finance;
