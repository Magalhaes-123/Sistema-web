// ═══════════════════════════════════════════════════════════════════════════════
// PURCHASES MODULE
// ═══════════════════════════════════════════════════════════════════════════════

export function Purchases({ submodule }) {
  const SuppliersView = () => (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Fornecedores</h2>
        <button style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Novo Fornecedor</button>
      </div>

      <div style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ color: "#495057", fontSize: 14, textAlign: "center", padding: "40px 20px" }}>
          Nenhum fornecedor registado
        </div>
      </div>
    </div>
  );

  const PurchaseOrdersView = () => (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Encomendas de Compra</h2>
        <button style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Nova Encomenda</button>
      </div>

      <div style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ color: "#495057", fontSize: 14, textAlign: "center", padding: "40px 20px" }}>
          Nenhuma encomenda registada
        </div>
      </div>
    </div>
  );

  switch (submodule) {
    case "suppliers":
      return <SuppliersView />;
    case "purchase-orders":
      return <PurchaseOrdersView />;
    default:
      return <SuppliersView />;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// INVOICING MODULE
// ═══════════════════════════════════════════════════════════════════════════════

export function Invoicing({ submodule }) {
  const InvoicesView = () => (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Faturas</h2>
        <button style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Nova Fatura</button>
      </div>

      <div style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ color: "#495057", fontSize: 14, textAlign: "center", padding: "40px 20px" }}>
          Nenhuma fatura registada
        </div>
      </div>
    </div>
  );

  const ReceiptsView = () => (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Recibos</h2>
        <button style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Novo Recibo</button>
      </div>

      <div style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ color: "#495057", fontSize: 14, textAlign: "center", padding: "40px 20px" }}>
          Nenhum recibo registado
        </div>
      </div>
    </div>
  );

  switch (submodule) {
    case "invoices":
      return <InvoicesView />;
    case "receipts":
      return <ReceiptsView />;
    default:
      return <InvoicesView />;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// TREASURY MODULE
// ═══════════════════════════════════════════════════════════════════════════════

export function Treasury({ submodule }) {
  const CashRegistersView = () => (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Caixas</h2>
        <button style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Nova Caixa</button>
      </div>

      <div style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ color: "#495057", fontSize: 14, textAlign: "center", padding: "40px 20px" }}>
          Nenhuma caixa registada
        </div>
      </div>
    </div>
  );

  const BankAccountsView = () => (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Contas Bancárias</h2>
        <button style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Nova Conta</button>
      </div>

      <div style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ color: "#495057", fontSize: 14, textAlign: "center", padding: "40px 20px" }}>
          Nenhuma conta registada
        </div>
      </div>
    </div>
  );

  switch (submodule) {
    case "cash-registers":
      return <CashRegistersView />;
    case "bank-accounts":
      return <BankAccountsView />;
    default:
      return <CashRegistersView />;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// FINANCE MODULE
// ═══════════════════════════════════════════════════════════════════════════════

export function Finance({ submodule }) {
  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ margin: "0 0 20px 0", fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Módulo Finanças</h2>
      <div style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ color: "#495057", fontSize: 14 }}>
          Submódulo: <strong>{submodule}</strong>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// LOGISTICS MODULE
// ═══════════════════════════════════════════════════════════════════════════════

export function Logistics({ submodule }) {
  const DeliveriesView = () => (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Entregas</h2>
        <button style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Nova Entrega</button>
      </div>

      <div style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ color: "#495057", fontSize: 14, textAlign: "center", padding: "40px 20px" }}>
          Nenhuma entrega registada
        </div>
      </div>
    </div>
  );

  const DriversView = () => (
    <div style={{ padding: "20px" }}>
      <h2 style={{ margin: "0 0 20px 0", fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Motoristas</h2>
      <div style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ color: "#495057", fontSize: 14, textAlign: "center", padding: "40px 20px" }}>
          Nenhum motorista registado
        </div>
      </div>
    </div>
  );

  switch (submodule) {
    case "deliveries":
      return <DeliveriesView />;
    case "drivers":
      return <DriversView />;
    default:
      return <DeliveriesView />;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARKETING MODULE
// ═══════════════════════════════════════════════════════════════════════════════

export function Marketing({ submodule }) {
  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ margin: "0 0 20px 0", fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Marketing & Campanhas</h2>
      <div style={{
        background: "#fff",
        borderRadius: 12,
        padding: "20px",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <div style={{ color: "#495057", fontSize: 14 }}>
          Submódulo: <strong>{submodule}</strong>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// REPORTS MODULE
// ═══════════════════════════════════════════════════════════════════════════════

export function Reports({ submodule }) {
  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ margin: "0 0 20px 0", fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Relatórios</h2>
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
        gap: 16,
      }}>
        {[
          { icon: "📊", title: "Vendas", desc: "Análise de vendas por período" },
          { icon: "💰", title: "Financeiros", desc: "Demonstrações financeiras" },
          { icon: "📦", title: "Inventário", desc: "Situação do stock" },
          { icon: "🏦", title: "Tesouraria", desc: "Fluxo de caixa" },
        ].map((r, i) => (
          <div key={i} style={{
            background: "#fff",
            borderRadius: 12,
            padding: "20px",
            boxShadow: "0 1px 3px rgba(0,0,0,.06)",
            cursor: "pointer",
            transition: "all .2s",
          }}>
            <div style={{ fontSize: 28, marginBottom: 12 }}>{r.icon}</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#0a1428", marginBottom: 6 }}>{r.title}</div>
            <div style={{ fontSize: 12, color: "#6c757d" }}>{r.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SETTINGS MODULE
// ═══════════════════════════════════════════════════════════════════════════════

export function Settings() {
  const [tab, setTab] = require("react").useState("empresa");

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ margin: "0 0 20px 0", fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Configurações</h2>

      <div style={{ display: "flex", gap: 20 }}>
        <div style={{ width: 200 }}>
          {[
            { id: "empresa", label: "Empresa" },
            { id: "usuarios", label: "Utilizadores" },
            { id: "permissoes", label: "Permissões" },
            { id: "integracao", label: "Integração" },
            { id: "backup", label: "Backup" },
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                display: "block",
                width: "100%",
                padding: "12px 16px",
                textAlign: "left",
                background: tab === t.id ? "#0099ff" : "transparent",
                color: tab === t.id ? "#fff" : "#495057",
                border: "none",
                borderRadius: 8,
                cursor: "pointer",
                fontWeight: tab === t.id ? 700 : 500,
                fontSize: 13,
                marginBottom: 8,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div style={{ flex: 1 }}>
          <div style={{
            background: "#fff",
            borderRadius: 12,
            padding: "20px",
            boxShadow: "0 1px 3px rgba(0,0,0,.06)",
          }}>
            <h3 style={{ margin: "0 0 16px 0", fontSize: 14, fontWeight: 700, color: "#0a1428" }}>
              {tab === "empresa" && "Dados da Empresa"}
              {tab === "usuarios" && "Gestão de Utilizadores"}
              {tab === "permissoes" && "Controlo de Permissões"}
              {tab === "integracao" && "Integrações Externas"}
              {tab === "backup" && "Sistema de Backup"}
            </h3>
            <div style={{ color: "#6c757d", fontSize: 13 }}>
              Conteúdo da aba {tab}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
