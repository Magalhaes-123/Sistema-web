import { useState } from "react";

const PRODUCTS_DATA = [
  { id: 1, sku: "PROD-001", name: "Laptop Dell XPS 15", category: "Eletrónicos", price: 1299, stock: 45, minStock: 10 },
  { id: 2, sku: "PROD-002", name: "Mouse Logitech MX", category: "Periféricos", price: 99, stock: 230, minStock: 50 },
  { id: 3, sku: "PROD-003", name: "Teclado Mecânico", category: "Periféricos", price: 199, stock: 15, minStock: 20 },
  { id: 4, sku: "PROD-004", name: "Monitor LG 27in", category: "Displays", price: 349, stock: 8, minStock: 5 },
  { id: 5, sku: "PROD-005", name: "Webcam Logitech", category: "Periféricos", price: 89, stock: 42, minStock: 15 },
];

const WAREHOUSES_DATA = [
  { id: 1, name: "Armazém Lisboa", location: "Lisboa", capacity: 5000, used: 3200 },
  { id: 2, name: "Armazém Porto", location: "Porto", capacity: 3000, used: 1800 },
  { id: 3, name: "Armazém Covilhã", location: "Covilhã", capacity: 2000, used: 800 },
];

const STOCK_MOVEMENTS = [
  { id: 1, type: "entrada", product: "Laptop Dell XPS 15", qty: 20, warehouse: "Lisboa", date: "2024-06-15" },
  { id: 2, type: "saida", product: "Mouse Logitech MX", qty: 5, warehouse: "Porto", date: "2024-06-14" },
  { id: 3, type: "ajuste", product: "Teclado Mecânico", qty: -2, warehouse: "Lisboa", date: "2024-06-13" },
  { id: 4, type: "entrada", product: "Monitor LG 27in", qty: 10, warehouse: "Covilhã", date: "2024-06-12" },
];

function ProductsView() {
  const [products, setProducts] = useState(PRODUCTS_DATA);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({ sku: "", name: "", category: "", price: 0, stock: 0, minStock: 0 });

  const handleSave = () => {
    if (editingId) {
      setProducts(products.map(p => p.id === editingId ? { ...formData, id: editingId } : p));
      setEditingId(null);
    } else {
      setProducts([...products, { ...formData, id: Date.now() }]);
    }
    setFormData({ sku: "", name: "", category: "", price: 0, stock: 0, minStock: 0 });
    setShowForm(false);
  };

  const handleDelete = (id) => {
    setProducts(products.filter(p => p.id !== id));
  };

  const handleEdit = (product) => {
    setFormData(product);
    setEditingId(product.id);
    setShowForm(true);
  };

  return (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Produtos ({products.length})</h2>
        <button onClick={() => { setShowForm(true); setEditingId(null); setFormData({ sku: "", name: "", category: "", price: 0, stock: 0, minStock: 0 }); }} style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Novo Produto</button>
      </div>

      {showForm && (
        <div style={{
          background: "#f8f9fa",
          borderRadius: 12,
          padding: "20px",
          marginBottom: 20,
          border: "1px solid #e5e9f0",
        }}>
          <h3 style={{ margin: "0 0 16px 0", fontSize: 14, fontWeight: 700, color: "#0a1428" }}>
            {editingId ? "Editar Produto" : "Novo Produto"}
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            {[
              { key: "sku", label: "SKU", type: "text" },
              { key: "name", label: "Nome", type: "text" },
              { key: "category", label: "Categoria", type: "text" },
              { key: "price", label: "Preço (€)", type: "number" },
              { key: "stock", label: "Stock", type: "number" },
              { key: "minStock", label: "Stock Mín.", type: "number" },
            ].map(field => (
              <div key={field.key}>
                <label style={{ display: "block", fontSize: 12, fontWeight: 700, color: "#495057", marginBottom: 6 }}>
                  {field.label}
                </label>
                <input
                  type={field.type}
                  value={formData[field.key]}
                  onChange={(e) => setFormData({ ...formData, [field.key]: field.type === "number" ? Number(e.target.value) : e.target.value })}
                  style={{
                    width: "100%",
                    padding: "8px 12px",
                    border: "1px solid #dee2e6",
                    borderRadius: 6,
                    fontSize: 12,
                    boxSizing: "border-box",
                  }}
                />
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
            <button onClick={handleSave} style={{
              background: "#37c74d",
              color: "#fff",
              border: "none",
              borderRadius: 6,
              padding: "8px 16px",
              fontWeight: 700,
              cursor: "pointer",
              fontSize: 12,
            }}>Guardar</button>
            <button onClick={() => setShowForm(false)} style={{
              background: "#e5e9f0",
              color: "#495057",
              border: "none",
              borderRadius: 6,
              padding: "8px 16px",
              fontWeight: 700,
              cursor: "pointer",
              fontSize: 12,
            }}>Cancelar</button>
          </div>
        </div>
      )}

      <div style={{
        background: "#fff",
        borderRadius: 12,
        overflow: "hidden",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: "#f8f9fa", borderBottom: "2px solid #e5e9f0" }}>
              {["SKU", "Nome", "Categoria", "Preço", "Stock", "Stock Mín.", "Ações"].map((h) => (
                <th key={h} style={{ textAlign: "left", padding: "12px", fontWeight: 700, color: "#495057", fontSize: 11, textTransform: "uppercase" }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {products.map((p, i) => (
              <tr key={p.id} style={{ borderBottom: "1px solid #e5e9f0", background: i % 2 === 0 ? "transparent" : "#f8f9fa" }}>
                <td style={{ padding: "12px", fontWeight: 700, color: "#0099ff" }}>{p.sku}</td>
                <td style={{ padding: "12px", color: "#0a1428" }}>{p.name}</td>
                <td style={{ padding: "12px", color: "#495057" }}>{p.category}</td>
                <td style={{ padding: "12px", fontWeight: 700, color: "#0a1428" }}>€{p.price.toFixed(2)}</td>
                <td style={{ padding: "12px" }}>
                  <span style={{
                    padding: "4px 8px",
                    borderRadius: 6,
                    fontSize: 11,
                    fontWeight: 700,
                    background: p.stock < p.minStock ? "#ffd6d6" : "#d4f5d4",
                    color: p.stock < p.minStock ? "#dc3545" : "#37c74d",
                  }}>
                    {p.stock} un
                  </span>
                </td>
                <td style={{ padding: "12px", color: "#495057" }}>{p.minStock} un</td>
                <td style={{ padding: "12px", display: "flex", gap: 8 }}>
                  <button onClick={() => handleEdit(p)} style={{
                    background: "#cfe2ff",
                    color: "#084298",
                    border: "none",
                    borderRadius: 4,
                    padding: "4px 8px",
                    fontWeight: 700,
                    cursor: "pointer",
                    fontSize: 11,
                  }}>Editar</button>
                  <button onClick={() => handleDelete(p.id)} style={{
                    background: "#f8d7da",
                    color: "#721c24",
                    border: "none",
                    borderRadius: 4,
                    padding: "4px 8px",
                    fontWeight: 700,
                    cursor: "pointer",
                    fontSize: 11,
                  }}>Apagar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function WarehousesView() {
  const [warehouses] = useState(WAREHOUSES_DATA);

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ margin: "0 0 20px 0", fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Armazéns</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
        {warehouses.map((w) => (
          <div key={w.id} style={{
            background: "#fff",
            borderRadius: 12,
            padding: "20px",
            boxShadow: "0 1px 3px rgba(0,0,0,.06)",
          }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: "#0a1428", marginBottom: 12 }}>
              📍 {w.name}
            </div>
            <div style={{ fontSize: 12, color: "#495057", marginBottom: 12 }}>{w.location}</div>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#495057", marginBottom: 6 }}>
                Ocupação: {Math.round((w.used / w.capacity) * 100)}%
              </div>
              <div style={{
                background: "#e5e9f0",
                height: 8,
                borderRadius: 4,
                overflow: "hidden",
              }}>
                <div style={{
                  background: "linear-gradient(90deg, #0099ff, #00d4ff)",
                  height: "100%",
                  width: `${(w.used / w.capacity) * 100}%`,
                  transition: "width .3s",
                }}></div>
              </div>
            </div>
            <div style={{ fontSize: 12, color: "#6c757d" }}>
              {w.used}/{w.capacity} un
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StockMovementsView() {
  const [movements] = useState(STOCK_MOVEMENTS);

  const typeLabel = (type) => {
    const labels = { entrada: "Entrada", saida: "Saída", ajuste: "Ajuste" };
    return labels[type] || type;
  };

  return (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Movimentos de Stock</h2>
        <button style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Novo Movimento</button>
      </div>

      <div style={{
        background: "#fff",
        borderRadius: 12,
        overflow: "hidden",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: "#f8f9fa", borderBottom: "2px solid #e5e9f0" }}>
              {["Tipo", "Produto", "Qtd", "Armazém", "Data"].map((h) => (
                <th key={h} style={{ textAlign: "left", padding: "12px", fontWeight: 700, color: "#495057", fontSize: 11, textTransform: "uppercase" }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {movements.map((m, i) => (
              <tr key={m.id} style={{ borderBottom: "1px solid #e5e9f0", background: i % 2 === 0 ? "transparent" : "#f8f9fa" }}>
                <td style={{ padding: "12px" }}>
                  <span style={{
                    padding: "4px 10px",
                    borderRadius: 6,
                    fontSize: 11,
                    fontWeight: 700,
                    background: m.type === "entrada" ? "#d4f5d4" : m.type === "saida" ? "#cfe2ff" : "#fff3cd",
                    color: m.type === "entrada" ? "#37c74d" : m.type === "saida" ? "#084298" : "#856404",
                  }}>
                    {typeLabel(m.type)}
                  </span>
                </td>
                <td style={{ padding: "12px", color: "#0a1428", fontWeight: 500 }}>{m.product}</td>
                <td style={{ padding: "12px", fontWeight: 700, color: m.qty > 0 ? "#37c74d" : "#dc3545" }}>
                  {m.qty > 0 ? "+" : ""}{m.qty}
                </td>
                <td style={{ padding: "12px", color: "#495057" }}>{m.warehouse}</td>
                <td style={{ padding: "12px", color: "#6c757d", fontSize: 12 }}>{m.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function Inventory({ submodule }) {
  switch (submodule) {
    case "products":
      return <ProductsView />;
    case "warehouses":
      return <WarehousesView />;
    case "stock-movements":
      return <StockMovementsView />;
    default:
      return <ProductsView />;
  }
}
