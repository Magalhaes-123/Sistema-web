import { useState } from "react";

export function Settings() {
  const [tab, setTab] = useState("empresa");

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ margin: "0 0 20px 0", fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Configurações</h2>
      <div style={{ display: "flex", gap: 20 }}>
        <div style={{ width: 200 }}>
          {[
            { id: "empresa", label: "Empresa" },
            { id: "usuarios", label: "Utilizadores" },
            { id: "permissoes", label: "Permissões" },
            { id: "backup", label: "Backup" },
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                display: "block",
                width: "100%",
                padding: "12px 16px",
                textAlign: "left",
                background: tab === t.id ? "#0099ff" : "transparent",
                color: tab === t.id ? "#fff" : "#495057",
                border: "none",
                borderRadius: 8,
                cursor: "pointer",
                fontWeight: tab === t.id ? 700 : 500,
                fontSize: 13,
                marginBottom: 8,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div style={{ flex: 1, background: "#fff", borderRadius: 12, padding: "20px", boxShadow: "0 1px 3px rgba(0,0,0,.06)" }}>
          <h3 style={{ margin: "0 0 16px 0", fontSize: 14, fontWeight: 700, color: "#0a1428" }}>
            {tab === "empresa" && "Dados da Empresa"}
            {tab === "usuarios" && "Gestão de Utilizadores"}
            {tab === "permissoes" && "Controlo de Permissões"}
            {tab === "backup" && "Sistema de Backup"}
          </h3>
          <div style={{ color: "#6c757d", fontSize: 13 }}>Configuração de {tab}</div>
        </div>
      </div>
    </div>
  );
}

export default Settings;
