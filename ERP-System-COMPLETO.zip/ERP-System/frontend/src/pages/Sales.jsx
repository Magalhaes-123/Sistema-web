import { useState } from "react";

const CUSTOMERS_DATA = [
  { id: 1, name: "Tech Solutions Lda", taxId: "PT123456789", email: "contact@techsol.pt", phone: "212345678", city: "Lisboa", creditLimit: 50000, status: "Ativo" },
  { id: 2, name: "Global Imports SA", taxId: "PT987654321", email: "sales@globalimports.pt", phone: "219876543", city: "Porto", creditLimit: 75000, status: "Ativo" },
  { id: 3, name: "MegaStore Portugal", taxId: "PT111222333", email: "info@megastore.pt", phone: "213334444", city: "Covilhã", creditLimit: 100000, status: "Ativo" },
];

const ORDERS_DATA = [
  { id: 1, reference: "PV-2024-0891", customer: "Tech Solutions", total: 12450, status: "Entregue", date: "2024-06-15" },
  { id: 2, reference: "PV-2024-0890", customer: "Global Imports", total: 8200, status: "Em Trânsito", date: "2024-06-14" },
  { id: 3, reference: "PV-2024-0889", customer: "MegaStore", total: 34700, status: "Pendente", date: "2024-06-13" },
  { id: 4, reference: "PV-2024-0888", customer: "Tech Solutions", total: 6100, status: "Processando", date: "2024-06-12" },
];

const QUOTATIONS_DATA = [
  { id: 1, reference: "COT-2024-0451", customer: "Novo Cliente", total: 25000, status: "Rascunho", date: "2024-06-15", validity: "2024-06-30" },
  { id: 2, reference: "COT-2024-0450", customer: "Tech Solutions", total: 15000, status: "Enviada", date: "2024-06-14", validity: "2024-06-29" },
  { id: 3, reference: "COT-2024-0449", customer: "Global Imports", total: 45000, status: "Aceita", date: "2024-06-10", validity: "2024-06-25" },
];

function CustomersView() {
  const [customers, setCustomers] = useState(CUSTOMERS_DATA);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({ name: "", taxId: "", email: "", phone: "", city: "", creditLimit: 0 });

  const handleSave = () => {
    if (editingId) {
      setCustomers(customers.map(c => c.id === editingId ? { ...c, ...formData } : c));
      setEditingId(null);
    } else {
      setCustomers([...customers, { ...formData, id: Date.now(), status: "Ativo" }]);
    }
    setFormData({ name: "", taxId: "", email: "", phone: "", city: "", creditLimit: 0 });
    setShowForm(false);
  };

  const handleEdit = (customer) => {
    const { name, taxId, email, phone, city, creditLimit } = customer;
    setFormData({ name, taxId, email, phone, city, creditLimit });
    setEditingId(customer.id);
    setShowForm(true);
  };

  return (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Clientes ({customers.length})</h2>
        <button onClick={() => { setShowForm(true); setEditingId(null); }} style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Novo Cliente</button>
      </div>

      {showForm && (
        <div style={{
          background: "#f8f9fa",
          borderRadius: 12,
          padding: "20px",
          marginBottom: 20,
          border: "1px solid #e5e9f0",
        }}>
          <h3 style={{ margin: "0 0 16px 0", fontSize: 14, fontWeight: 700, color: "#0a1428" }}>
            {editingId ? "Editar Cliente" : "Novo Cliente"}
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            {[
              { key: "name", label: "Nome", type: "text" },
              { key: "taxId", label: "NIF", type: "text" },
              { key: "email", label: "Email", type: "email" },
              { key: "phone", label: "Telefone", type: "text" },
              { key: "city", label: "Cidade", type: "text" },
              { key: "creditLimit", label: "Limite Crédito (€)", type: "number" },
            ].map(field => (
              <div key={field.key}>
                <label style={{ display: "block", fontSize: 12, fontWeight: 700, color: "#495057", marginBottom: 6 }}>
                  {field.label}
                </label>
                <input
                  type={field.type}
                  value={formData[field.key]}
                  onChange={(e) => setFormData({ ...formData, [field.key]: field.type === "number" ? Number(e.target.value) : e.target.value })}
                  style={{
                    width: "100%",
                    padding: "8px 12px",
                    border: "1px solid #dee2e6",
                    borderRadius: 6,
                    fontSize: 12,
                    boxSizing: "border-box",
                  }}
                />
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
            <button onClick={handleSave} style={{
              background: "#37c74d",
              color: "#fff",
              border: "none",
              borderRadius: 6,
              padding: "8px 16px",
              fontWeight: 700,
              cursor: "pointer",
              fontSize: 12,
            }}>Guardar</button>
            <button onClick={() => setShowForm(false)} style={{
              background: "#e5e9f0",
              color: "#495057",
              border: "none",
              borderRadius: 6,
              padding: "8px 16px",
              fontWeight: 700,
              cursor: "pointer",
              fontSize: 12,
            }}>Cancelar</button>
          </div>
        </div>
      )}

      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(350px, 1fr))",
        gap: 16,
      }}>
        {customers.map((c) => (
          <div key={c.id} style={{
            background: "#fff",
            borderRadius: 12,
            padding: "20px",
            boxShadow: "0 1px 3px rgba(0,0,0,.06)",
            borderLeft: "4px solid #0099ff",
          }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#0a1428", marginBottom: 8 }}>
              {c.name}
            </div>
            <div style={{ fontSize: 12, color: "#6c757d", marginBottom: 12, display: "flex", flexDirection: "column", gap: 4 }}>
              <div>📋 NIF: {c.taxId}</div>
              <div>📧 {c.email}</div>
              <div>📱 {c.phone}</div>
              <div>📍 {c.city}</div>
            </div>
            <div style={{ fontSize: 12, color: "#495057", marginBottom: 12, paddingTop: 12, borderTop: "1px solid #e5e9f0" }}>
              Limite Crédito: <span style={{ fontWeight: 700, color: "#0a1428" }}>€{c.creditLimit.toLocaleString()}</span>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => handleEdit(c)} style={{
                background: "#cfe2ff",
                color: "#084298",
                border: "none",
                borderRadius: 6,
                padding: "6px 12px",
                fontWeight: 700,
                cursor: "pointer",
                fontSize: 11,
                flex: 1,
              }}>Editar</button>
              <button style={{
                background: "#e7e7e7",
                color: "#495057",
                border: "none",
                borderRadius: 6,
                padding: "6px 12px",
                fontWeight: 700,
                cursor: "pointer",
                fontSize: 11,
                flex: 1,
              }}>Apagar</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function OrdersView() {
  const [orders] = useState(ORDERS_DATA);

  return (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Encomendas de Venda</h2>
        <button style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Nova Encomenda</button>
      </div>

      <div style={{
        background: "#fff",
        borderRadius: 12,
        overflow: "hidden",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: "#f8f9fa", borderBottom: "2px solid #e5e9f0" }}>
              {["Referência", "Cliente", "Total", "Estado", "Data", "Ações"].map((h) => (
                <th key={h} style={{ textAlign: "left", padding: "12px", fontWeight: 700, color: "#495057", fontSize: 11, textTransform: "uppercase" }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {orders.map((o, i) => (
              <tr key={o.id} style={{ borderBottom: "1px solid #e5e9f0", background: i % 2 === 0 ? "transparent" : "#f8f9fa" }}>
                <td style={{ padding: "12px", fontWeight: 700, color: "#0099ff" }}>{o.reference}</td>
                <td style={{ padding: "12px", color: "#0a1428" }}>{o.customer}</td>
                <td style={{ padding: "12px", fontWeight: 700, color: "#0a1428" }}>€{o.total.toLocaleString()}</td>
                <td style={{ padding: "12px" }}>
                  <span style={{
                    padding: "4px 10px",
                    borderRadius: 6,
                    fontSize: 11,
                    fontWeight: 700,
                    background: o.status === "Entregue" ? "#d4f5d4" : o.status === "Em Trânsito" ? "#cfe2ff" : o.status === "Pendente" ? "#fff3cd" : "#f8d7da",
                    color: o.status === "Entregue" ? "#37c74d" : o.status === "Em Trânsito" ? "#084298" : o.status === "Pendente" ? "#856404" : "#721c24",
                  }}>
                    {o.status}
                  </span>
                </td>
                <td style={{ padding: "12px", color: "#6c757d", fontSize: 12 }}>{o.date}</td>
                <td style={{ padding: "12px", display: "flex", gap: 6 }}>
                  <button style={{
                    background: "#cfe2ff",
                    color: "#084298",
                    border: "none",
                    borderRadius: 4,
                    padding: "4px 8px",
                    fontWeight: 700,
                    cursor: "pointer",
                    fontSize: 11,
                  }}>Ver</button>
                  <button style={{
                    background: "#f8d7da",
                    color: "#721c24",
                    border: "none",
                    borderRadius: 4,
                    padding: "4px 8px",
                    fontWeight: 700,
                    cursor: "pointer",
                    fontSize: 11,
                  }}>Excluir</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function QuotationsView() {
  const [quotations] = useState(QUOTATIONS_DATA);

  return (
    <div style={{ padding: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Cotações</h2>
        <button style={{
          background: "linear-gradient(135deg, #0099ff, #00d4ff)",
          color: "#fff",
          border: "none",
          borderRadius: 8,
          padding: "10px 20px",
          fontWeight: 700,
          cursor: "pointer",
          fontSize: 12,
        }}>+ Nova Cotação</button>
      </div>

      <div style={{
        background: "#fff",
        borderRadius: 12,
        overflow: "hidden",
        boxShadow: "0 1px 3px rgba(0,0,0,.06)",
      }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: "#f8f9fa", borderBottom: "2px solid #e5e9f0" }}>
              {["Referência", "Cliente", "Total", "Estado", "Validade", "Ações"].map((h) => (
                <th key={h} style={{ textAlign: "left", padding: "12px", fontWeight: 700, color: "#495057", fontSize: 11, textTransform: "uppercase" }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {quotations.map((q, i) => (
              <tr key={q.id} style={{ borderBottom: "1px solid #e5e9f0", background: i % 2 === 0 ? "transparent" : "#f8f9fa" }}>
                <td style={{ padding: "12px", fontWeight: 700, color: "#0099ff" }}>{q.reference}</td>
                <td style={{ padding: "12px", color: "#0a1428" }}>{q.customer}</td>
                <td style={{ padding: "12px", fontWeight: 700, color: "#0a1428" }}>€{q.total.toLocaleString()}</td>
                <td style={{ padding: "12px" }}>
                  <span style={{
                    padding: "4px 10px",
                    borderRadius: 6,
                    fontSize: 11,
                    fontWeight: 700,
                    background: q.status === "Aceita" ? "#d4f5d4" : q.status === "Enviada" ? "#cfe2ff" : "#f8d7da",
                    color: q.status === "Aceita" ? "#37c74d" : q.status === "Enviada" ? "#084298" : "#721c24",
                  }}>
                    {q.status}
                  </span>
                </td>
                <td style={{ padding: "12px", color: "#6c757d", fontSize: 12 }}>{q.validity}</td>
                <td style={{ padding: "12px", display: "flex", gap: 6 }}>
                  <button style={{
                    background: "#37c74d",
                    color: "#fff",
                    border: "none",
                    borderRadius: 4,
                    padding: "4px 8px",
                    fontWeight: 700,
                    cursor: "pointer",
                    fontSize: 11,
                  }}>Converter</button>
                  <button style={{
                    background: "#cfe2ff",
                    color: "#084298",
                    border: "none",
                    borderRadius: 4,
                    padding: "4px 8px",
                    fontWeight: 700,
                    cursor: "pointer",
                    fontSize: 11,
                  }}>Ver</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function Sales({ submodule }) {
  switch (submodule) {
    case "customers":
      return <CustomersView />;
    case "orders":
      return <OrdersView />;
    case "quotations":
      return <QuotationsView />;
    default:
      return <CustomersView />;
  }
}
