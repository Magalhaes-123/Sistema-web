export function Reports({ submodule }) {
  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ margin: "0 0 20px 0", fontSize: 18, fontWeight: 700, color: "#0a1428" }}>Relatórios</h2>
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
        gap: 16,
      }}>
        {[
          { icon: "📊", title: "Vendas", desc: "Análise de vendas" },
          { icon: "💰", title: "Financeiros", desc: "Demonstrações financeiras" },
          { icon: "📦", title: "Inventário", desc: "Situação do stock" },
          { icon: "🏦", title: "Tesouraria", desc: "Fluxo de caixa" },
        ].map((r, i) => (
          <div key={i} style={{
            background: "#fff",
            borderRadius: 12,
            padding: "20px",
            boxShadow: "0 1px 3px rgba(0,0,0,.06)",
          }}>
            <div style={{ fontSize: 28, marginBottom: 12 }}>{r.icon}</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: "#0a1428", marginBottom: 6 }}>{r.title}</div>
            <div style={{ fontSize: 12, color: "#6c757d" }}>{r.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Reports;
