import { useState, useEffect } from "react";
import Dashboard from "./pages/Dashboard";
import Inventory from "./pages/Inventory";
import Sales from "./pages/Sales";
import Purchases from "./pages/Purchases";
import Invoicing from "./pages/Invoicing";
import Treasury from "./pages/Treasury";
import Finance from "./pages/Finance";
import Logistics from "./pages/Logistics";
import Marketing from "./pages/Marketing";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";

export default function App() {
  const [currentModule, setCurrentModule] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(t);
  }, []);

  const timeStr = now.toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
  const dateStr = now.toLocaleDateString("pt-PT", { weekday: "long", day: "numeric", month: "long" });

  const NAV_ITEMS = [
    { id: "dashboard", icon: "📊", label: "Dashboard", subItems: [] },
    {
      id: "inventory",
      icon: "📦",
      label: "Inventário",
      subItems: [
        { id: "products", label: "Produtos" },
        { id: "warehouses", label: "Armazéns" },
        { id: "stock-movements", label: "Movimentos Stock" },
      ],
    },
    {
      id: "purchases",
      icon: "🛒",
      label: "Compras",
      subItems: [
        { id: "suppliers", label: "Fornecedores" },
        { id: "purchase-orders", label: "Encomendas Compra" },
        { id: "purchase-returns", label: "Devoluções" },
      ],
    },
    {
      id: "sales",
      icon: "💼",
      label: "Vendas",
      subItems: [
        { id: "customers", label: "Clientes" },
        { id: "quotations", label: "Cotações" },
        { id: "orders", label: "Encomendas" },
        { id: "returns", label: "Devoluções" },
      ],
    },
    {
      id: "invoicing",
      icon: "🧾",
      label: "Faturação",
      subItems: [
        { id: "invoices", label: "Faturas" },
        { id: "receipts", label: "Recibos" },
        { id: "credit-notes", label: "Notas Crédito" },
        { id: "debit-notes", label: "Notas Débito" },
      ],
    },
    {
      id: "treasury",
      icon: "🏦",
      label: "Tesouraria",
      subItems: [
        { id: "cash-registers", label: "Caixas" },
        { id: "bank-accounts", label: "Contas Bancárias" },
        { id: "payments", label: "Pagamentos" },
        { id: "reconciliation", label: "Reconciliação" },
      ],
    },
    {
      id: "finance",
      icon: "📈",
      label: "Finanças",
      subItems: [
        { id: "accounting", label: "Contabilidade" },
        { id: "journals", label: "Diários" },
        { id: "budgets", label: "Orçamentos" },
        { id: "cost-centers", label: "Centros Custo" },
      ],
    },
    {
      id: "logistics",
      icon: "🚚",
      label: "Logística",
      subItems: [
        { id: "deliveries", label: "Entregas" },
        { id: "drivers", label: "Motoristas" },
        { id: "vehicles", label: "Veículos" },
        { id: "routes", label: "Rotas" },
      ],
    },
    {
      id: "marketing",
      icon: "📣",
      label: "Marketing",
      subItems: [
        { id: "campaigns", label: "Campanhas" },
        { id: "leads", label: "Leads" },
        { id: "crm", label: "CRM" },
      ],
    },
    {
      id: "reports",
      icon: "📊",
      label: "Relatórios",
      subItems: [
        { id: "sales-reports", label: "Vendas" },
        { id: "financial-reports", label: "Financeiros" },
        { id: "inventory-reports", label: "Inventário" },
      ],
    },
    { id: "settings", icon: "⚙️", label: "Configurações", subItems: [] },
  ];

  const renderContent = () => {
    switch (currentModule) {
      case "dashboard":
        return <Dashboard />;
      case "inventory":
        return <Inventory submodule={currentModule} />;
      case "products":
      case "warehouses":
      case "stock-movements":
        return <Inventory submodule={currentModule} />;
      case "purchases":
      case "suppliers":
      case "purchase-orders":
      case "purchase-returns":
        return <Purchases submodule={currentModule} />;
      case "sales":
      case "customers":
      case "quotations":
      case "orders":
      case "returns":
        return <Sales submodule={currentModule} />;
      case "invoicing":
      case "invoices":
      case "receipts":
      case "credit-notes":
      case "debit-notes":
        return <Invoicing submodule={currentModule} />;
      case "treasury":
      case "cash-registers":
      case "bank-accounts":
      case "payments":
      case "reconciliation":
        return <Treasury submodule={currentModule} />;
      case "finance":
      case "accounting":
      case "journals":
      case "budgets":
      case "cost-centers":
        return <Finance submodule={currentModule} />;
      case "logistics":
      case "deliveries":
      case "drivers":
      case "vehicles":
      case "routes":
        return <Logistics submodule={currentModule} />;
      case "marketing":
      case "campaigns":
      case "leads":
      case "crm":
        return <Marketing submodule={currentModule} />;
      case "reports":
      case "sales-reports":
      case "financial-reports":
      case "inventory-reports":
        return <Reports submodule={currentModule} />;
      case "settings":
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div style={{
      display: "flex",
      height: "100vh",
      fontFamily: "'Segoe UI', sans-serif",
      background: "#f5f7fa",
      overflow: "hidden",
    }}>
      {/* ── SIDEBAR ── */}
      <aside style={{
        width: sidebarOpen ? 260 : 80,
        background: "linear-gradient(180deg, #0a1428 0%, #0d1b2a 100%)",
        display: "flex",
        flexDirection: "column",
        transition: "width .3s cubic-bezier(.4,.0,.2,1)",
        overflow: "hidden",
        flexShrink: 0,
        borderRight: "1px solid rgba(255,255,255,.05)",
        boxShadow: "2px 0 12px rgba(0,0,0,.15)",
      }}>
        {/* Logo */}
        <div style={{
          padding: "20px 16px",
          display: "flex",
          alignItems: "center",
          gap: 12,
          cursor: "pointer",
          transition: "all .25s",
        }} onClick={() => setSidebarOpen(!sidebarOpen)}>
          <div style={{
            width: 40,
            height: 40,
            borderRadius: 12,
            background: "linear-gradient(135deg, #00d4ff, #0099ff)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 22,
            fontWeight: 900,
            flexShrink: 0,
            boxShadow: "0 8px 24px rgba(0,212,255,.3)",
          }}>⚡</div>
          {sidebarOpen && (
            <span style={{
              color: "#fff",
              fontWeight: 900,
              fontSize: 18,
              letterSpacing: "-1px",
              background: "linear-gradient(90deg, #00d4ff 0%, #0099ff 100%)",
              backgroundClip: "text",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}>ERPNova</span>
          )}
        </div>

        {/* Nav */}
        <nav style={{
          flex: 1,
          padding: "16px 8px",
          overflowY: "auto",
          scrollBehavior: "smooth",
        }}>
          {NAV_ITEMS.map((item, idx) => (
            <NavItem
              key={item.id}
              item={item}
              isOpen={sidebarOpen}
              isActive={currentModule === item.id || item.subItems.some(s => s.id === currentModule)}
              onSelect={(id) => setCurrentModule(id)}
              delay={idx * 0.05}
            />
          ))}
        </nav>

        {/* User */}
        <div style={{
          padding: "12px 16px",
          borderTop: "1px solid rgba(255,255,255,.08)",
          display: "flex",
          alignItems: "center",
          gap: 12,
        }}>
          <div style={{
            width: 36,
            height: 36,
            borderRadius: 50,
            background: "linear-gradient(135deg, #ff6b6b, #ff8787)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#fff",
            fontWeight: 800,
            fontSize: 14,
            flexShrink: 0,
          }}>AM</div>
          {sidebarOpen && (
            <div>
              <div style={{ color: "#fff", fontSize: 12, fontWeight: 700 }}>Admin Master</div>
              <div style={{ color: "rgba(255,255,255,.4)", fontSize: 11 }}>Administrador</div>
            </div>
          )}
        </div>
      </aside>

      {/* ── MAIN ── */}
      <main style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* TOPBAR */}
        <header style={{
          background: "#fff",
          borderBottom: "1px solid #e5e9f0",
          padding: "0 28px",
          height: 70,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexShrink: 0,
          boxShadow: "0 2px 8px rgba(0,0,0,.04)",
        }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 900, color: "#0a1428", textTransform: "capitalize" }}>
              {NAV_ITEMS.find(i => i.id === (NAV_ITEMS.find(ni => ni.subItems.some(s => s.id === currentModule))?.id || currentModule))?.label || currentModule}
            </div>
            <div style={{ fontSize: 12, color: "#6c757d", marginTop: 2 }}>{dateStr}</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
            <input type="text" placeholder="🔍 Pesquisar..." style={{
              background: "#f8f9fa",
              border: "1px solid #dee2e6",
              borderRadius: 8,
              padding: "8px 16px",
              fontSize: 13,
              color: "#495057",
              width: 200,
            }} />
            <div style={{
              position: "relative",
              width: 40,
              height: 40,
              background: "#f8f9fa",
              border: "1px solid #dee2e6",
              borderRadius: 8,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              fontSize: 18,
            }}>
              🔔
              <div style={{
                position: "absolute",
                top: 6,
                right: 6,
                width: 10,
                height: 10,
                borderRadius: "50%",
                background: "#dc3545",
              }} />
            </div>
            <div style={{
              fontFamily: "'Courier New', monospace",
              fontSize: 13,
              fontWeight: 700,
              color: "#0a1428",
            }}>{timeStr}</div>
          </div>
        </header>

        {/* CONTENT */}
        <div style={{ flex: 1, overflow: "auto" }}>
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

function NavItem({ item, isOpen, isActive, onSelect, delay }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div style={{ animation: isOpen ? `slideIn .5s ease-out ${delay}s both` : "none" }}>
      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(-20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        .nav-btn:hover { background: rgba(255,255,255,.12) !important; }
        .nav-btn.active { background: rgba(0,212,255,.15) !important; box-shadow: inset 0 0 8px rgba(0,212,255,.2); }
      `}</style>
      <button onClick={() => {
        if (item.subItems.length > 0) {
          setExpanded(!expanded);
        } else {
          onSelect(item.id);
        }
      }} className={`nav-btn ${isActive ? "active" : ""}`} style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        width: "100%",
        padding: "12px 14px",
        borderRadius: 10,
        border: "none",
        background: isActive ? "rgba(0,212,255,.15)" : "transparent",
        color: isActive ? "#00d4ff" : "rgba(255,255,255,.6)",
        fontSize: 13,
        fontWeight: isActive ? 700 : 500,
        cursor: "pointer",
        transition: "all .2s",
        textAlign: "left",
        whiteSpace: "nowrap",
      }}>
        <span style={{ fontSize: 18, flexShrink: 0 }}>{item.icon}</span>
        {isOpen && (
          <>
            <span style={{ flex: 1 }}>{item.label}</span>
            {item.subItems.length > 0 && (
              <span style={{
                transform: expanded ? "rotate(180deg)" : "rotate(0)",
                transition: "transform .2s",
                fontSize: 12,
              }}>▼</span>
            )}
          </>
        )}
      </button>

      {isOpen && expanded && item.subItems.length > 0 && (
        <div style={{
          background: "rgba(255,255,255,.03)",
          margin: "4px 0",
          borderRadius: 8,
          overflow: "hidden",
        }}>
          {item.subItems.map((sub) => (
            <button
              key={sub.id}
              onClick={() => {
                onSelect(sub.id);
                setExpanded(false);
              }}
              style={{
                display: "flex",
                alignItems: "center",
                width: "100%",
                padding: "10px 14px 10px 38px",
                background: currentModule === sub.id ? "rgba(0,212,255,.15)" : "transparent",
                color: currentModule === sub.id ? "#00d4ff" : "rgba(255,255,255,.5)",
                fontSize: 12,
                fontWeight: currentModule === sub.id ? 700 : 400,
                border: "none",
                cursor: "pointer",
                transition: "all .15s",
              }}
              onMouseEnter={(e) => {
                e.target.style.background = "rgba(255,255,255,.08)";
              }}
              onMouseLeave={(e) => {
                e.target.style.background = currentModule === sub.id ? "rgba(0,212,255,.15)" : "transparent";
              }}
            >
              {sub.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

const currentModule = null; // Fix for sub item check
