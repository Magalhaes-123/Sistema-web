// Global state
