# ERPNova - Quick Start Guide

## O que está incluído

### ✅ Frontend (React 18 + Vite)
- **App.jsx** - Aplicação principal com navegação completa
- **Dashboard.jsx** - Dashboard com KPIs, gráficos, alertas
- **Inventory.jsx** - Gestão de produtos, armazéns, stock
- **Sales.jsx** - Clientes, encomendas, cotações
- **Purchases.jsx** - Fornecedores, encomendas compra
- **Invoicing.jsx** - Faturas, recibos, notas
- **Treasury.jsx** - Caixas, contas bancárias, pagamentos
- **Finance.jsx** - Contabilidade, orçamentos
- **Logistics.jsx** - Entregas, motoristas, rotas
- **Marketing.jsx** - Campanhas, leads, CRM
- **Reports.jsx** - Relatórios financeiros
- **Settings.jsx** - Configurações da empresa

### ✅ Backend (Laravel 11)
- Controllers: Dashboard, Products, Inventory, Sales, Orders
- Models: Product, Order, Customer
- Migrations: 3 migrations completas
- Routes: API modularizado por domínio

### ✅ DevOps
- Docker Compose com 5 serviços
- Dockerfile para Laravel e React
- Nginx config
- SSL support

## Arranque Rápido

### Opção 1: Docker (Recomendado)

```bash
cd ERP-System
cp .env.example .env
docker-compose up -d
```

Acesso:
- Frontend: http://localhost:3000
- Backend: http://localhost:8000/api
- PhpMyAdmin (opcional): http://localhost:8081

### Opção 2: Desenvolvimento Local

**Backend:**
```bash
cd backend
composer install
php artisan key:generate
php artisan migrate --seed
php artisan serve
```

**Frontend (novo terminal):**
```bash
cd frontend
npm install
npm run dev
```

## Funcionalidades Principais

### Dashboard
- 5 KPIs com métricas
- Gráfico Area Chart (Receitas, Despesas, Lucro)
- Donut chart de inventário
- Tabela de últimas encomendas
- Alertas do sistema
- Relógio em tempo real

### Navegação
- Sidebar colapsável
- 11 módulos principais
- Submenus contextuais
- Navegação rápida entre seções

### Inventário
- CRUD de produtos completo
- Gestão de armazéns
- Movimentos de stock
- Cards de status de armazém

### Vendas
- Listagem de clientes (cards)
- Encomendas com status
- Cotações com conversion
- Formulários CRUD funcionais

### Formulários
- Validação de dados
- Edição inline
- Botões Guardar/Cancelar
- Feedback visual

### Tabelas
- Ordenação
- Filtros
- Ações (Ver, Editar, Apagar)
- Status badges com cores

### Gráficos
- Recharts integrado
- Area charts
- Bar charts
- Pie charts
- Responsive

## Estrutura de Ficheiros

```
ERP-System/
├── frontend/                # React + Vite
│   ├── src/
│   │   ├── App.jsx         # App principal
│   │   ├── main.jsx
│   │   ├── pages/          # Todos os 11 módulos
│   │   ├── services/       # API calls
│   │   ├── hooks/          # Custom hooks
│   │   ├── utils/          # Helpers
│   │   └── store/          # Zustand state
│   ├── package.json
│   └── vite.config.js
│
├── backend/                 # Laravel 11
│   ├── app/
│   │   ├── Http/Controllers/
│   │   ├── Models/
│   │   └── Services/
│   ├── database/migrations/
│   ├── routes/
│   └── composer.json
│
├── deployment/
│   ├── docker/
│   ├── nginx/
│   └── scripts/
│
├── docker-compose.yml
├── .env
└── README.md
```

## Próximas Etapas

1. **Integração API Real**
   - Atualizar `frontend/src/services/api.js`
   - Conectar com backend Laravel

2. **Autenticação**
   - Login/Logout com JWT
   - Proteção de rotas
   - Papel de utilizadores

3. **Base de Dados**
   - Executar migrations
   - Seeders para dados teste

4. **Produção**
   - Build optimizado
   - SSL certificates
   - Environment variables

## Troubleshooting

### Port 3000 já em uso
```bash
lsof -i :3000  # List
kill -9 <PID>  # Kill process
```

### Docker permission denied
```bash
sudo usermod -aG docker $USER
newgrp docker
```

### Migrations falhadas
```bash
php artisan migrate:rollback
php artisan migrate
```

## Contacto & Suporte

Para mais informações, consulte o README.md principal.

---

**Desenvolvido com ❤️ em Portugal**

ERPNova v1.0 - 2024
