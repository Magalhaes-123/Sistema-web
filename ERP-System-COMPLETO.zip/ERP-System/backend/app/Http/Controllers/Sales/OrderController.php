<?php

namespace App\Http\Controllers\Sales;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $orders = Order::query()
            ->with(['customer', 'items.product'])
            ->when($request->status, fn($q, $s) => $q->where('status', $s))
            ->when($request->customer_id, fn($q, $id) => $q->where('customer_id', $id))
            ->latest()
            ->paginate($request->per_page ?? 20);

        return response()->json($orders);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'items'       => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity'   => 'required|integer|min:1',
            'items.*.price'      => 'required|numeric|min:0',
            'notes'       => 'nullable|string',
        ]);

        $order = Order::createWithItems($validated);

        return response()->json($order->load(['customer', 'items.product']), 201);
    }

    public function show(Order $order): JsonResponse
    {
        return response()->json($order->load(['customer', 'items.product', 'invoices']));
    }

    public function update(Request $request, Order $order): JsonResponse
    {
        $order->update($request->all());
        return response()->json($order);
    }

    public function destroy(Order $order): JsonResponse
    {
        $order->delete();
        return response()->json(null, 204);
    }

    public function confirm(Order $order): JsonResponse
    {
        $order->confirm();
        return response()->json($order);
    }

    public function cancel(Order $order): JsonResponse
    {
        $order->cancel();
        return response()->json($order);
    }
}
