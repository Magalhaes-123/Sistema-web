<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class DashboardController extends Controller
{
    public function kpis(): JsonResponse
    {
        return response()->json([
            'receitas_mes' => 257000,
            'receitas_delta' => 14.2,
            'vendas_total' => 1842,
            'vendas_delta' => 8.7,
            'clientes_ativos' => 346,
            'clientes_delta' => 5.1,
            'stock_total' => 48291,
            'stock_delta' => -2.3,
            'a_receber' => 89000,
            'a_receber_delta' => -6.4,
        ]);
    }

    public function revenueChart(): JsonResponse
    {
        $data = [
            ['month' => 'Jan', 'receitas' => 142000, 'despesas' => 98000, 'lucro' => 44000],
            ['month' => 'Fev', 'receitas' => 168000, 'despesas' => 112000, 'lucro' => 56000],
            ['month' => 'Mar', 'receitas' => 195000, 'despesas' => 125000, 'lucro' => 70000],
            ['month' => 'Abr', 'receitas' => 178000, 'despesas' => 118000, 'lucro' => 60000],
            ['month' => 'Mai', 'receitas' => 221000, 'despesas' => 134000, 'lucro' => 87000],
            ['month' => 'Jun', 'receitas' => 257000, 'despesas' => 149000, 'lucro' => 108000],
        ];

        return response()->json($data);
    }

    public function alerts(): JsonResponse
    {
        return response()->json([
            ['type' => 'danger', 'message' => '5 produtos abaixo do stock mínimo', 'created_at' => now()],
            ['type' => 'warning', 'message' => '3 faturas a vencer em 2 dias', 'created_at' => now()->subHour()],
            ['type' => 'info', 'message' => 'Encomenda #PC-0341 recebida no armazém', 'created_at' => now()->subHours(2)],
            ['type' => 'success', 'message' => 'Reconciliação bancária concluída', 'created_at' => now()->subHours(3)],
        ]);
    }

    public function recentOrders(): JsonResponse
    {
        // TODO: Replace with real DB query
        return response()->json([]);
    }
}
