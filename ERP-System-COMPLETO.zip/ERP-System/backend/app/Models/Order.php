<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'reference', 'customer_id', 'status',
        'subtotal', 'tax', 'discount', 'total',
        'notes', 'confirmed_at', 'delivered_at',
    ];

    protected $casts = [
        'subtotal'     => 'decimal:2',
        'tax'          => 'decimal:2',
        'discount'     => 'decimal:2',
        'total'        => 'decimal:2',
        'confirmed_at' => 'datetime',
        'delivered_at' => 'datetime',
    ];

    const STATUS_PENDING    = 'pending';
    const STATUS_CONFIRMED  = 'confirmed';
    const STATUS_PROCESSING = 'processing';
    const STATUS_SHIPPED    = 'shipped';
    const STATUS_DELIVERED  = 'delivered';
    const STATUS_CANCELLED  = 'cancelled';

    public function customer() { return $this->belongsTo(Customer::class); }
    public function items()    { return $this->hasMany(OrderItem::class); }
    public function invoices() { return $this->hasMany(Invoice::class); }

    public static function createWithItems(array $data): self
    {
        $order = static::create([
            'reference'   => 'PV-' . date('Y') . '-' . str_pad(static::count() + 1, 4, '0', STR_PAD_LEFT),
            'customer_id' => $data['customer_id'],
            'status'      => self::STATUS_PENDING,
            'notes'       => $data['notes'] ?? null,
        ]);

        foreach ($data['items'] as $item) {
            $order->items()->create($item);
        }

        $order->recalculate();
        return $order;
    }

    public function recalculate(): void
    {
        $subtotal = $this->items->sum(fn($i) => $i->quantity * $i->price);
        $this->update(['subtotal' => $subtotal, 'total' => $subtotal]);
    }

    public function confirm(): void
    {
        $this->update(['status' => self::STATUS_CONFIRMED, 'confirmed_at' => now()]);
    }

    public function cancel(): void
    {
        $this->update(['status' => self::STATUS_CANCELLED]);
    }
}
