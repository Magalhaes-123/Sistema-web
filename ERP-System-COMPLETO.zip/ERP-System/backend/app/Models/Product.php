<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name', 'sku', 'barcode', 'description',
        'category_id', 'brand_id',
        'price', 'cost', 'tax_rate',
        'min_stock', 'max_stock',
        'unit', 'is_active', 'image',
    ];

    protected $casts = [
        'price'    => 'decimal:2',
        'cost'     => 'decimal:2',
        'tax_rate' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function category() { return $this->belongsTo(Category::class); }
    public function brand()    { return $this->belongsTo(Brand::class); }
    public function stockMovements() { return $this->hasMany(StockMovement::class); }

    public function stockByWarehouse(): array
    {
        return $this->stockMovements()
            ->selectRaw('warehouse_id, SUM(quantity) as total')
            ->groupBy('warehouse_id')
            ->with('warehouse:id,name')
            ->get()
            ->toArray();
    }
}
