<?php
use App\Http\Controllers\Dashboard\DashboardController;
use Illuminate\Support\Facades\Route;

Route::get('/kpis', [DashboardController::class, 'kpis']);
Route::get('/revenue-chart', [DashboardController::class, 'revenueChart']);
Route::get('/alerts', [DashboardController::class, 'alerts']);
Route::get('/recent-orders', [DashboardController::class, 'recentOrders']);
