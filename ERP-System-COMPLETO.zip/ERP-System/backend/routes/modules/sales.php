<?php
use App\Http\Controllers\Sales\CustomerController;
use App\Http\Controllers\Sales\OrderController;
use App\Http\Controllers\Sales\QuotationController;
use Illuminate\Support\Facades\Route;

Route::apiResource('customers', CustomerController::class);
Route::apiResource('orders', OrderController::class);
Route::apiResource('quotations', QuotationController::class);
Route::post('orders/{order}/confirm', [OrderController::class, 'confirm']);
Route::post('orders/{order}/cancel', [OrderController::class, 'cancel']);
