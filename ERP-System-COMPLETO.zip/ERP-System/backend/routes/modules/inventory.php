<?php
use App\Http\Controllers\Inventory\ProductController;
use App\Http\Controllers\Inventory\WarehouseController;
use App\Http\Controllers\Inventory\StockMovementController;
use Illuminate\Support\Facades\Route;

Route::apiResource('products', ProductController::class);
Route::apiResource('warehouses', WarehouseController::class);
Route::get('products/{product}/stock', [ProductController::class, 'stock']);
Route::post('stock-movements', [StockMovementController::class, 'store']);
