<?php
use Illuminate\Support\Facades\Route;

Route::prefix('auth')->group(base_path('routes/modules/auth.php'));

Route::middleware('auth:sanctum')->group(function () {
    Route::prefix('dashboard')->group(base_path('routes/modules/dashboard.php'));
    Route::prefix('inventory')->group(base_path('routes/modules/inventory.php'));
    Route::prefix('sales')->group(base_path('routes/modules/sales.php'));
    Route::prefix('purchases')->group(base_path('routes/modules/purchases.php'));
    Route::prefix('invoicing')->group(base_path('routes/modules/invoicing.php'));
    Route::prefix('treasury')->group(base_path('routes/modules/treasury.php'));
    Route::prefix('finance')->group(base_path('routes/modules/finance.php'));
    Route::prefix('logistics')->group(base_path('routes/modules/logistics.php'));
    Route::prefix('reports')->group(base_path('routes/modules/reports.php'));
});
