# ERPNova — Sistema ERP Completo

## Stack Tecnológica

| Layer      | Tecnologia                        |
|------------|-----------------------------------|
| Backend    | PHP 8.2 + Laravel 11              |
| Frontend   | React 18 + Vite + Recharts        |
| Base Dados | MySQL 8.0                         |
| Cache/Queue| Redis 7                           |
| Servidor   | Nginx + PHP-FPM                   |
| Containers | Docker + Docker Compose           |

## Módulos

- **Dashboard** — KPIs, gráficos, alertas em tempo real
- **Inventário** — Produtos, categorias, marcas, armazéns, movimentos de stock
- **Compras** — Fornecedores, encomendas de compra, devoluções, aprovações
- **Vendas** — Clientes, cotações, encomendas, devoluções, comissões
- **Faturação** — Faturas, recibos, notas de crédito/débito
- **Tesouraria** — Caixas, contas bancárias, pagamentos, reconciliação
- **Finanças** — Contabilidade, diários, centros de custo, orçamentos
- **Logística** — Veículos, motoristas, entregas, rotas, tracking
- **Marketing** — Campanhas, leads, CRM, analytics
- **Relatórios** — Relatórios financeiros e operacionais

## Arranque Rápido

### Com Docker (recomendado)

```bash
cp .env.example .env
docker-compose up -d
docker-compose exec app php artisan migrate --seed
```

Acesso:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000/api
- Credenciais padrão: admin@erp.local / password

### Sem Docker

```bash
# Backend
cd backend
composer install
php artisan key:generate
php artisan migrate --seed
php artisan serve

# Frontend (novo terminal)
cd frontend
npm install
npm run dev
```

## Estrutura do Projeto

```
ERP-System/
├── backend/          # Laravel 11 API
│   ├── app/
│   │   ├── Http/Controllers/   # Por módulo
│   │   ├── Models/             # Eloquent Models
│   │   ├── Services/           # Business logic
│   │   └── ...
│   ├── database/migrations/
│   └── routes/modules/
├── frontend/         # React + Vite
│   └── src/modules/  # Um directório por módulo
├── deployment/       # Docker, Nginx, SSL
└── docs/             # Documentação
```

## API Endpoints Principais

| Método | Endpoint                        | Descrição                  |
|--------|---------------------------------|----------------------------|
| GET    | /api/dashboard/kpis             | KPIs do dashboard          |
| GET    | /api/inventory/products         | Listar produtos             |
| POST   | /api/sales/orders               | Criar encomenda             |
| POST   | /api/sales/orders/{id}/confirm  | Confirmar encomenda         |
| GET    | /api/invoicing/invoices         | Listar faturas              |

## Licença

Propriedade privada — todos os direitos reservados.
